# DetectGPT (Webapp)

## Introduction
This is the webapp for our implementation of detectGPT

## installation
pip install -r requirements.txt

## Usage

``` 4d
uvicorn main:app
```

```

## Acknowledgements
1. Mitchell, Eric, et al. "DetectGPT: Zero-Shot Machine-Generated Text Detection using Probability Curvature." arXiv preprint arXiv:2301.11305 (2023).



